<?php

$host = 'localhost';
$nama = 'root';
$pass = '';
$db = 'budgetbuddy';

$koneksi = mysqli_connect($host, $nama,$pass, $db);
?>