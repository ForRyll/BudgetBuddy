<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="shortcut icon" href="img/logo_BB.png">
  <title>Login | Keuangan</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

  <style>
    body {
      background: linear-gradient(90deg, #FC466B 0%, #3F5EFB 100%);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    @media (max-width: 576px) {
      .text-logo {
        font-size: 1rem;
      }
    }

    .logo-container {
      display: flex;
      align-items: center;
      justify-content: center;
      margin-bottom: 20px;
    }

    .logo-container img {
      max-height: 50px;
      margin-right: 10px;
    }

    .card {
      border-radius: 20px;
    }

    @media (max-width: 576px) {
      .card {
        box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
      }

      .form-control-user {
        font-size: 14px;
        padding: 10px;
      }

      .btn-user {
        font-size: 14px;
        padding: 10px 20px;
      }
    }
  </style>
</head>

<body>
  <div class="container">
    <!-- Outer Row -->
    <div class="row justify-content-center">
      <div class="col-xl-5 col-lg-6 col-md-8">
        <div class="card o-hidden border-0 shadow-lg my-5">
          <div class="p-5">
              <!-- Logo and Title -->
              <div class="logo-container">
              <img src="img/logo_BB.png" alt="Logo">
              <h1 class="h5 text-gray-900 mb-2 text-logo"><b>Budget Buddy</b></h1>
            </div>
            <form class="user" action="proses-regist.php" method="post">
              <div class="form-group">
                <input type="text" name="nama" class="form-control form-control-user" id="exampleInputNama" placeholder="Input Nama Anda..." required>
              </div>
              <div class="form-group">
                <input type="email" name="email" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Input Email..." required>
              </div>
              <div class="form-group">
                <input type="password" name="pass" class="form-control form-control-user" id="exampleInputPassword" placeholder=" Input Password..." required>
              </div>
              
              <button type="submit" name="submit" class="btn btn-primary btn-user btn-block">Daftar</button>
            </form>
            <hr>
            <div class="text-center">
              <a class="small" href="forgot-password.php">Lupa Password?</a>
              <a class="small" href="login.php">Masuk</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>
</body>

</html>
