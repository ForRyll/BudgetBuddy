<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'tambah') {
        $catatan = mysqli_real_escape_string($koneksi, $_POST['catatan']);
        mysqli_query($koneksi, "INSERT INTO catatan (catatan) VALUES ('$catatan')");
        header('Location: index.php'); // Ganti dengan halaman Anda
    }

    if ($action === 'hapus') {
        $id_catatan = (int)$_POST['id_catatan'];
        mysqli_query($koneksi, "DELETE FROM catatan WHERE id_catatan = $id_catatan");
        header('Location: index.php'); // Ganti dengan halaman Anda
    }

    if ($action === 'edit') {
        $id_catatan = (int)$_POST['id_catatan'];
        $catatan = mysqli_real_escape_string($koneksi, $_POST['catatan']);
        mysqli_query($koneksi, "UPDATE catatan SET catatan = '$catatan' WHERE id_catatan = $id_catatan");
        header('Location: index.php'); // Ganti dengan halaman Anda
    }
}
?>

