<?php
session_start();

include('koneksi.php');

define('LOG','log.txt');

function write_log($log){  
    $time = date('[Y-m-d H:i:s]');
    $op = $time.' '.$log."\n".PHP_EOL;
    $fp = fopen(LOG, 'a');
    fwrite($fp, $op);
    fclose($fp);
}

// Validasi input
if (!isset($_GET['id_pemasukan']) || 
    !isset($_GET['tgl_pemasukan']) || 
    !isset($_GET['jumlah']) || 
    !isset($_GET['id_sumber'])) {
    die("Parameter tidak lengkap");
}

// Sanitasi input
$id = mysqli_real_escape_string($koneksi, $_GET['id_pemasukan']);
$tgl = mysqli_real_escape_string($koneksi, $_GET['tgl_pemasukan']);
$jumlah = mysqli_real_escape_string($koneksi, $_GET['jumlah']);
$sumber = mysqli_real_escape_string($koneksi, $_GET['id_sumber']);

// Validasi tanggal
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $tgl)) {
    die("Format tanggal tidak valid");
}

// Validasi jumlah (pastikan adalah angka positif)
if (!is_numeric($jumlah) || $jumlah <= 0) {
    die("Jumlah harus berupa angka positif");
}

// Prepared statement untuk keamanan
$query = "UPDATE pemasukan 
          SET tgl_pemasukan = ?, 
              jumlah = ?, 
              id_sumber = ? 
          WHERE id_pemasukan = ?";

$stmt = mysqli_prepare($koneksi, $query);
mysqli_stmt_bind_param($stmt, "siii", $tgl, $jumlah, $sumber, $id);

$namaadmin = $_SESSION['nama'] ?? 'Unknown';

if (mysqli_stmt_execute($stmt)) {
    // Cek apakah ada baris yang diupdate
    if (mysqli_stmt_affected_rows($stmt) > 0) {
        write_log("Nama Admin : ".$namaadmin." => Edit Pemasukan => ".$id." => Sukses Edit");
        
        // Sweet Alert untuk konfirmasi
        echo "<script>
                alert('Data berhasil diupdate');
                window.location.href = 'pendapatan.php';
              </script>";
        exit();
    } else {
        write_log("Nama Admin : ".$namaadmin." => Edit Pemasukan => ".$id." => Tidak Ada Perubahan");
        
        echo "<script>
                alert('Tidak ada perubahan data');
                window.location.href = 'pendapatan.php';
              </script>";
        exit();
    }
} else {
    // Log error database
    write_log("Nama Admin : ".$namaadmin." => Edit Pemasukan => ".$id." => Gagal Edit: " . mysqli_stmt_error($stmt));
    
    echo "<script>
            alert('Gagal update: " . mysqli_stmt_error($stmt) . "');
            window.location.href = 'pendapatan.php';
          </script>";
    exit();
}

// Tutup statement
mysqli_stmt_close($stmt);
mysqli_close($koneksi);
?>