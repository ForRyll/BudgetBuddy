      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; 2024 - <a href='#' title='sharecodingan.blogspot.com' target='_blank'>BudgetBuddy</a>
            </span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->