<?php
// mengaktifkan session php
session_start();
 
// menghubungkan dengan koneksi
include 'koneksi.php';
 
// menangkap data yang dikirim dari form
$email = mysqli_real_escape_string($koneksi, $_POST['email']);
$pass = mysqli_real_escape_string($koneksi, $_POST['pass']);
$nama = mysqli_real_escape_string($koneksi, $_POST['nama']); // Menambahkan kolom nama
 
// Query untuk memasukkan data admin baru
$query = "INSERT INTO admin (email, pass, nama) VALUES ('$email', '$pass', '$nama')";
 
// Mengeksekusi query
if (mysqli_query($koneksi, $query)) {
    // Jika berhasil memasukkan data, lakukan redirect atau berikan pesan sukses
    header("Location: login.php?pesan=berhasil");
} else {
    // Jika gagal, beri pesan error
    header("Location: register.php?pesan=gagal");
}
?>
